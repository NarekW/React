import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Header from './App';
import Main from './Moduls/Main.js';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<Header />,document.querySelector('#root'));
ReactDOM.render(<Main />,document.querySelector('#main'));

//---------------
var Divs = document.querySelector('#what');
console.log(Divs);

function Blur(){
    console.log('blue');
}
function OffMousedown(){
    document.addEventListener('mouseout', Blur)
}
function OnMouseover(){
    this.style.backgroundColor = "red";
    console.log('sdsdsd');
    OffMousedown();
   
}
Divs.addEventListener('mouseover',OnMouseover);
//----------------
serviceWorker.unregister();
