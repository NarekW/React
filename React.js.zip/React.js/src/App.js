import React, { Component } from 'react';
import logo from './as.png';
import logo2 from './rollworks-logo.jpg'

import './App.css';




class Header extends React.Component{

    render(){
        
        return(
            
            <div id="HeaderDiv">
                <ul id="HeaderUl">
                    <li className="HeaderLi" id="logo1Li">
                        <a>
                        <img src={logo}/>
                        </a>
                    </li>
                    <li className="HeaderLi">
                        <a id="logo2">
                        <img src={logo2}/>
                        </a>
                    </li>
                    <li className="HeaderLi" id="language">
                        <a>
                        Home
                        </a>
                    </li>
                   </ul> 
                    
                   <nav id="Wappers2Nav">
                        <div id="Wappers2Div">
                            <ul id="Wappers2Ul">
                            <li className='Wappers2Li'>
                            <a className="WapersURl" href="sads">
                            Home
                            </a>
                            
                            </li>
                           
                            <li className='Wappers2Li'>
                            <a className="WapersURl" href="sads">
                            Why AdRoll?
                            </a>
                            </li>

                            <li className='Wappers2Li' id="what">
                            <a className="WapersURl" href="sads">
                            What you can do
                            </a>
                            </li>
                            <li className='Wappers2Li'>
                            <a className="WapersURl" href="sads">
                            Pricing
                            </a>
                            </li>

                            <li className='Wappers2Li'>
                            <a className="WapersURl" href="sads">
                            Partners
                            </a>
                            </li>

                            <li className='Wappers2Li'>
                            <a className="WapersURl" href="sads">
                            Lean More</a>
                            </li>
                            
                            <li className='Wappers2Li' id="login">
                            <a className="WapersURl" href="sads">
                            Login</a>
                            </li>

                            <li className='Wappers2Li' id="getstartedloginDiv">
                            <a className="WapersURl" id="url" href="sads">
                            GET STARTED</a>
                            </li>
                            
                            </ul>
                        </div>                           
                        </nav>
                        <nav id="trenav">
                        <ul>
                        <li className="nav3Lis">1</li>
                        <li className="nav3Lis">2</li>
                        <li className="nav3Lis">3</li>
                        </ul>
                            </nav>
                        </div> 
                    
         
                
        )
    }
}

export default Header;