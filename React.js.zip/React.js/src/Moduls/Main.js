import React from "react";


class Main extends React.Component{
    render()
    {
        return( 
            <section>
                <div id="OblojkaDiv">
                
                    <div id="Shapee1">
                    </div>
                    <div id="Shapee2">
                    </div>
                    <div id="SuperHero">
                    <div id="info">
                    <a href="sadasd">
                    <h4>Adam Lasky</h4>
                    <b>TeePublic</b>
                    <p>Doubled revenue over the holiday season.</p>
                    <p>READ CASE STUDY</p>
                    </a>
                    
                    </div>
                    <button className="buttons" id="bt1"></button>
                    <button className="buttons" id="bt2"></button>
                    </div>
                    <div id="Infomer">
                        <h1>Grow your business.
                            Boost your sales.</h1>
                        <p>Attract and convert visitors to your online store with display ads, social, email, and now video ads.</p>
                        <div id="getbutton">
                            <a>GET STARTED</a>
                        </div>
                        
                    </div>

                </div>
            </section>
        );
    }
}
export default Main;